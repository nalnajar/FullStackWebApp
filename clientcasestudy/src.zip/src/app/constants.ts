//export const BASEURL = 'http://localhost:8080/api/';
//export const PDFURL = 'http://localhost:8080/PurchaseOrderPDF?repid=';
export const BASEURL = '/api/';
export const PDFURL = '/POPDF?po=';