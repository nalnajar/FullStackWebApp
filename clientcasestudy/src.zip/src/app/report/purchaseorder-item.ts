export interface PurchaseOrderItem {
    id: number;
    purchaseorderid: number;
    productid: string;
    productName: string;
    qty:number;
    price:number;
}
